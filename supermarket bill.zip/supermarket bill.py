from datetime import datetime

name=input("Enter your name:")
print("welcome to supermarket",(name))
#list of items
list='''
bread               Rs 40
candy               Rs 20
hamburger           Rs 80
hotdog              Rs 60
sandwich            Rs 50
rice                Rs 85/kg
salt                Rs 20/kg
food_oil            Rs 90/liter
wheat               Rs 70/kg
sugar               Rs 30/kg
panner              Rs 120/kg
maggi               Rs 50
coke                Rs 40
boost               Rs 90
colgate             Rs 85
juice               Rs 40
waffer              Rs 50
biscuits            Rs 50
'''
#declaration
price=0
pricelist=[]
totalprice=0
finalprice=0
ilist=[]
qlist=[]
plist=[]

#rates for items
items={'bread':40,'candy':20,'hamburger':80,'hotdog':60,'sandwich':50,'rice':85,'salt':20,'food_oil':90,'wheat':70,'sugar':30,'panner':120,'Maggi':50,'coke':40,'Boost':90,'Colgate':85,'juice':40,'waffer':50,'biscuits':50 }
option=int(input("For list of items press 1:"))
if option==1:
    print(0* "=", "items", 12 * "=","price")
    print( 35 * "=", "")
    print(list)
    print(35 * "=", "")
for i in range (len(items)):
    inp1=int(input("If you want to buy press 1 or 2 for exit:"))
    if inp1==2:
        break
    if inp1==1:
        item=input("Enter your items:")
        quantity=int(input("Enter Quantity:"))
        if item in items.keys():
            price=quantity*(items[item])
            pricelist.append((item,quantity,items,price))
            totalprice+=price
            ilist.append(item)
            qlist.append(quantity)
            plist.append(price)
            gst=(totalprice*5)/100
            finalprice=gst+totalprice
        else:
            print("Sorry you entered item is not available")
    else:
        print("you entered Wrong number")
    inp=input("can i print the bill Yes or No:")
    if inp=='yes':
        pass
        if finalprice!=0:
            print(25*"=","Supermarket",25*"=")
            print("name:",name,30*" ","Date:",datetime.now())
            print(75*"-")
            print("S.No",8*" ",'items',8*" ",'Quantity',5*" ",'price')
            for i in range(len(pricelist)):
                print(i,8*" ",2*" ",ilist[i],10*" ",qlist[i],10*" ",plist[i])
            print(75*"-")
            print(50*" ",'TotalAmount:','Rs',totalprice)
            print('Gstamount',50*" ",'Rs',gst)
            print(75 * "-")
            print(50*" ",'finalPrice:','Rs',finalprice)
            print(75 * "-")
            print(25 * " ", "Thankyou Visit again")